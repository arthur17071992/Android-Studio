package com.example.arthurnguyen.concertticket;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.DecimalFormat;

public class GetConcertTickets extends AppCompatActivity {

    double costPerTicket = 59.99;
    double totalCost;
    int numberOfTickets;
    String groupChoice;
    ArrayAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_concert_tickets);

        adapter = ArrayAdapter.createFromResource(this, R.array.txtGroup, android.R.layout.simple_spinner_item);
        final EditText tickets = findViewById(R.id.txtField);
        final Spinner group = findViewById(R.id.txtGroup);
        group.setAdapter(adapter);
        Button cost = findViewById(R.id.orderTickets);
        cost.setOnClickListener(new View.OnClickListener() {
            final TextView result = findViewById(R.id.txtResult);
            @Override
            public void onClick(View view) {
                numberOfTickets = Integer.parseInt(tickets.getText().toString());
                totalCost = costPerTicket * numberOfTickets;
                DecimalFormat currency = new DecimalFormat("$###, ###.##");
                groupChoice = group.getSelectedItem().toString();
                result.setText("Cost for ' + groupChoice + ' is " + currency.format(totalCost));
            }
        });

    }
} // end class

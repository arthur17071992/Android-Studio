package com.example.arthurnguyen.electriccarfinancing;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.DialogInterface;


import java.text.DecimalFormat;

public class Payment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        TextView monthlyPayment = findViewById(R.id.txtMonthlyPayment);
        ImageView image = findViewById(R.id.imageView);
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        int intYears = sharedPref.getInt("key1", 0);
        int intLoan = sharedPref.getInt("key2", 0);
        float decInterest = sharedPref.getFloat("key3", 0);

        // calculate the monthly payment
        float decMonthlyPayment;
        decMonthlyPayment = (intLoan * (1 + (decInterest * intYears))) / (12 * intYears);
        DecimalFormat currency = new DecimalFormat("$###,###.##");

        // display monthly payment on text view
        monthlyPayment.setText("Monthly Payment" + currency.format(decMonthlyPayment));

        // create if condition display image base on input years
        if(intYears == 3){
            image.setImageResource(R.drawable.three);
        }
        else if(intYears == 4){
            image.setImageResource(R.drawable.four);
        }
        else if(intYears == 5){
            image.setImageResource(R.drawable.five);
        }
        else{
            // create alert and kickback to main activity
            AlertDialog alertDialog = new AlertDialog.Builder(Payment.this).create();
            alertDialog.setTitle("Alert Dialog");
            alertDialog.setMessage("Please enter 3, 4 or 5 years");
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Payment.this, MainActivity.class);
                    startActivity(intent);
                }
            });
            alertDialog.show();
        }
    }
} // end class Payment
